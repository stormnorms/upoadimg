<?php

/**
 * This is the template that renders the testimonial block.
 *
 * @param   array $block The block settings and attributes.
 * @param   bool $is_preview True during AJAX preview.
 */

 global $pakb_loop, $pakb_helper;

 ?><div class="pakb-section pakb-sidebar-main"><div class="uk-child-width-expand@m" data-uk-grid><?php dynamic_sidebar('pakb-main'); ?></div></div><?php
